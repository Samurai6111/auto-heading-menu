# custom-wordpress-editor

Wordpressの管理画面のエディターに機能追加するためのプラグインです。


アップデート履歴；
2021/07/20
アコーディオン追加
